/**
 * DEAF Reversal Portal — Apps Script backend
 * Script Properties:
 * SPREADSHEET_ID, SHEET_NAME, API_KEY
 *
 * USERS tab columns:
 * USERNAME | PASSWORD_HASH | ROLE | SOL_ID | ACTIVE
 */
const CONFIG = {
  SESSION_HOURS: 8,
  PROCESS_OPTIONS: [
    "Customer Contact","Customer Consent Obtained","Documents Awaited",
    "Documents Received","Claim / Reversal Request Submitted",
    "Reversal Under Process","Reversal Completed",
    "Account Holder Not Traceable","Customer Not Interested","Other"
  ],
  STATUS_OPTIONS: ["Pending","In Progress","Completed","Not Eligible","Rejected","Closed"],
  REVIEW_OPTIONS: ["Not Reviewed","Reviewed"]
};

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.callback && /^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(p.callback)) {
    return ContentService.createTextOutput(
      p.callback + "(" + JSON.stringify(route_(p)) + ");"
    ).setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(JSON.stringify({
    ok:true, service:"DEAF Reversal Portal API"
  })).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const p = Object.assign({}, (e && e.parameter) || {});
    if (e && e.postData && e.postData.contents) {
      try { Object.assign(p, JSON.parse(e.postData.contents)); } catch (_) {}
    }
    return ContentService.createTextOutput(JSON.stringify(route_(p)))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      ok:false, error:String(err && err.message || err)
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function route_(p) {
  const key = PropertiesService.getScriptProperties().getProperty("API_KEY");
  if (!key || String(p.apiKey || "") !== key) {
    return {ok:false,error:"Unauthorized request"};
  }
  const action = String(p.action || "");
  if (action === "login") return login_(p);
  const user = session_(String(p.token || ""));
  if (!user) return {ok:false,error:"Session expired. Sign in again."};
  if (action === "bootstrap") return {
    ok:true,user:user,processOptions:CONFIG.PROCESS_OPTIONS,
    statusOptions:CONFIG.STATUS_OPTIONS,reviewOptions:CONFIG.REVIEW_OPTIONS
  };
  if (action === "solSummary") return solSummary_(user);
  if (action === "list") return listAccounts_(user,p);
  if (action === "update") return updateAccount_(user,p);
  if (action === "logout") {
    CacheService.getScriptCache().remove("deaf_session_"+String(p.token));
    return {ok:true};
  }
  return {ok:false,error:"Unknown action"};
}

function login_(p) {
  const username=String(p.username||"").trim().toLowerCase();
  const hash=hashPassword_(String(p.password||""));
  const sh=getSheet_("USERS"), values=sh.getDataRange().getDisplayValues();
  if(values.length<2) return {ok:false,error:"No users configured"};
  const ix=indices_(values[0]);
  ["USERNAME","PASSWORD_HASH","ROLE","SOL_ID","ACTIVE"].forEach(h=>{
    if(ix[h]===undefined) throw new Error("USERS sheet missing "+h);
  });
  for(let i=1;i<values.length;i++){
    const r=values[i];
    if(String(r[ix.USERNAME]).trim().toLowerCase()!==username) continue;
    if(String(r[ix.ACTIVE]).trim().toUpperCase()!=="TRUE") break;
    if(String(r[ix.PASSWORD_HASH]).trim().toLowerCase()!==hash) break;
    const role=String(r[ix.ROLE]||"BRANCH").trim().toUpperCase();
    if(!["RO","ADMIN","BRANCH"].includes(role)) return {ok:false,error:"Invalid role"};
    const user={username:username,role:role,solId:String(r[ix.SOL_ID]||"").trim()};
    if(role==="BRANCH"&&!user.solId) return {ok:false,error:"No SOL ID assigned"};
    const token=Utilities.getUuid()+Utilities.getUuid().replace(/-/g,"");
    CacheService.getScriptCache().put("deaf_session_"+token,JSON.stringify(user),CONFIG.SESSION_HOURS*3600);
    return {ok:true,token:token,user:user};
  }
  return {ok:false,error:"Invalid username or password"};
}

function solSummary_(user) {
  const sh=getDataSheet_(), data=sh.getDataRange().getDisplayValues();
  if(!data.length) return {ok:true,sols:[]};
  const ix=indices_(data[0]), sols={};
  if(ix["SOL ID"]===undefined) throw new Error("SOL ID column missing");
  for(let i=1;i<data.length;i++){
    const r=data[i], sol=String(r[ix["SOL ID"]]||"").trim();
    if(!sol) continue;
    if(user.role==="BRANCH" && sol!==user.solId) continue;
    if(!sols[sol]) sols[sol]={solId:sol,branch:ix.BRANCH===undefined?"":String(r[ix.BRANCH]||""),accountCount:0,totalAmount:0};
    sols[sol].accountCount++;
    if(ix.AMOUNT!==undefined) sols[sol].totalAmount+=amount_(r[ix.AMOUNT]);
  }
  return {ok:true,sols:Object.keys(sols).sort().map(k=>sols[k])};
}

function listAccounts_(user,p) {
  const sh=getDataSheet_(), data=sh.getDataRange().getDisplayValues();
  if(!data.length) return {ok:true,headers:[],rows:[],total:0};
  const headers=data[0].map(h=>String(h).trim()), ix=indices_(headers);
  const requested=String(p.solId||"").trim(), q=String(p.q||"").trim().toLowerCase(), rows=[];
  for(let i=1;i<data.length;i++){
    const r=data[i], sol=String(r[ix["SOL ID"]]||"").trim();
    if(user.role==="BRANCH"&&sol!==user.solId) continue;
    if(requested&&["RO","ADMIN"].includes(user.role)&&sol!==requested) continue;
    const searchable=[val_(r,ix,"SOL ID"),val_(r,ix,"BRANCH"),val_(r,ix,"NAME"),val_(r,ix,"CUST ID"),val_(r,ix,"ACCOUNT NO"),val_(r,ix,"UDRN")].join(" ").toLowerCase();
    if(q&&!searchable.includes(q)) continue;
    const obj={}; headers.forEach((h,j)=>obj[h]=r[j]||"");
    obj._row=i+1;
    if(!obj.PROCESS)obj.PROCESS="Pending";
    if(!obj.STATUS)obj.STATUS="Pending";
    if(!obj["REVIEW STATUS"])obj["REVIEW STATUS"]="Not Reviewed";
    rows.push(obj);
  }
  return {ok:true,headers:headers,rows:rows,total:rows.length};
}

function updateAccount_(user,p) {
  const row=Number(p.row);
  if(!Number.isInteger(row)||row<2) return {ok:false,error:"Invalid account row"};
  const sh=getDataSheet_();
  if(row>sh.getLastRow()) return {ok:false,error:"Account not found"};
  const lock=LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const headers=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(h=>String(h).trim());
    const ix=indices_(headers);
    ["SOL ID","PROCESS","STATUS","REMARK"].forEach(h=>{if(ix[h]===undefined)throw new Error("Missing column "+h);});
    const sol=String(sh.getRange(row,ix["SOL ID"]+1).getDisplayValue()).trim();
    if(user.role==="BRANCH"&&sol!==user.solId) return {ok:false,error:"You may update only your own SOL ID"};
    const process=String(p.process||"").trim(), status=String(p.status||"").trim();
    const remark=String(p.remark||"").trim(), review=String(p.reviewStatus||"Reviewed").trim();
    if(!CONFIG.PROCESS_OPTIONS.includes(process))return {ok:false,error:"Invalid PROCESS"};
    if(!CONFIG.STATUS_OPTIONS.includes(status))return {ok:false,error:"Invalid STATUS"};
    if(!CONFIG.REVIEW_OPTIONS.includes(review))return {ok:false,error:"Invalid REVIEW STATUS"};
    sh.getRange(row,ix.PROCESS+1).setValue(process);
    sh.getRange(row,ix.STATUS+1).setValue(status);
    sh.getRange(row,ix.REMARK+1).setValue(remark);
    if(ix["REVIEW STATUS"]!==undefined) sh.getRange(row,ix["REVIEW STATUS"]+1).setValue(review);
    else {const c=sh.getLastColumn()+1;sh.getRange(1,c).setValue("REVIEW STATUS");sh.getRange(row,c).setValue(review);}
    return {ok:true,message:"Account updated",row:row};
  } finally {lock.releaseLock();}
}

function setup() {
  const props=PropertiesService.getScriptProperties();
  const id=props.getProperty("SPREADSHEET_ID"), name=props.getProperty("SHEET_NAME")||"DEAF";
  if(!id)throw new Error("Set SPREADSHEET_ID in Script Properties");
  if(!props.getProperty("API_KEY"))throw new Error("Set API_KEY in Script Properties");
  const ss=SpreadsheetApp.openById(id), data=ss.getSheetByName(name);
  if(!data)throw new Error("Data tab not found: "+name);
  const users=ss.getSheetByName("USERS")||ss.insertSheet("USERS");
  if(users.getLastRow()===0)users.appendRow(["USERNAME","PASSWORD_HASH","ROLE","SOL_ID","ACTIVE"]);
  const headers=data.getRange(1,1,1,data.getLastColumn()).getDisplayValues()[0].map(h=>String(h).trim().toUpperCase());
  ["PROCESS","STATUS","REMARK","REVIEW STATUS"].forEach(h=>{if(!headers.includes(h)){data.getRange(1,data.getLastColumn()+1).setValue(h);headers.push(h);}});
  return "Setup complete";
}
function makePasswordHash(password){return hashPassword_(String(password));}
function hashPassword_(password){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,password,Utilities.Charset.UTF_8).map(b=>("0"+((b+256)%256).toString(16)).slice(-2)).join("");}
function session_(token){if(!token)return null;const s=CacheService.getScriptCache().get("deaf_session_"+token);if(!s)return null;try{return JSON.parse(s);}catch(e){return null;}}
function getDataSheet_(){const p=PropertiesService.getScriptProperties(),id=p.getProperty("SPREADSHEET_ID"),name=p.getProperty("SHEET_NAME")||"DEAF";if(!id)throw new Error("SPREADSHEET_ID not configured");const s=SpreadsheetApp.openById(id).getSheetByName(name);if(!s)throw new Error("Data tab not found: "+name);return s;}
function getSheet_(name){const id=PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");if(!id)throw new Error("SPREADSHEET_ID not configured");const s=SpreadsheetApp.openById(id).getSheetByName(name);if(!s)throw new Error("Sheet not found: "+name);return s;}
function indices_(headers){const o={};headers.forEach((h,i)=>o[String(h).trim().toUpperCase()]=i);return o;}
function val_(row,ix,key){return ix[key]===undefined?"":row[ix[key]]||"";}
function amount_(v){const n=Number(String(v||"").replace(/[,₹\s]/g,""));return Number.isFinite(n)?n:0;}
